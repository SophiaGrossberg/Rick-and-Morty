export interface Character{
    id:number;
    name:String;
    image:String;
    species:string;
    gender:string;
    created:string;
    status:string;
}

