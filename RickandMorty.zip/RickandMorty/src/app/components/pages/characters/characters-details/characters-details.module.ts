import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CharactersDetailsRoutingModule } from './characters-details-routing.module';



@NgModule({
  declarations: [
    
  ],
  imports: [CommonModule,CharactersDetailsRoutingModule ]
})
export class CharactersDetailsModule { }
