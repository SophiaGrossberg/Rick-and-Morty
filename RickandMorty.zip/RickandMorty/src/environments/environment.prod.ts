export const environment = {
  production: true,
  baseUrlAPI: 'https://rickandmortyapi.com/api/character',
  
};
